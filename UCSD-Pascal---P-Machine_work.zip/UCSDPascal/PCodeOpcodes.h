// PCodeOpcodes.h
//
// Static, human-readable metadata for every possible p-code opcode byte
// value (0x00-0xFF), used by the View > Op Code Count dialog.
//
// Names for 0x80-0xFF come directly from SYSTEM.MICRO's XFRTBL jump
// table (transfer table at 0x0100, one entry per opcode, entry N =
// opcode 0x80+N -- see PSystemEngine::RunLoop for how this table is
// walked at runtime). Opcodes 0x00-0x7F never appear in that table --
// they're all SLDC (short load constant): the low 7 bits of the opcode
// byte ARE the constant being pushed, decoded by the SLDCI routine at
// 0x03AB rather than through the table. The SLDL/SLDO/SIND ranges within
// 0x80-0xFF work the same way (a small immediate packed into the low
// bits of several consecutive opcode values), which is why those names
// repeat across a run of opcodes instead of being unique.
//
// PCodeOpcodeIsNative() is the single source of truth for which opcodes
// currently have a native-C replacement in PSystemEngine::RunLoop().
// IMPORTANT: this list is maintained BY HAND and must be kept in sync
// with the `switch (m_cpu.r.PC)` block there -- add an opcode here at
// the same time you add its case in RunLoop(), not before or after.
#pragma once
#include <cstdint>

// P-Code Opcode Constants
#define OP_ABI    0x80
#define OP_ABR    0x81
#define OP_ADI    0x82
#define OP_ADR    0x83
#define OP_LAND   0x84
#define OP_DIF    0x85
#define OP_DVI    0x86
#define OP_DVR    0x87
#define OP_CHK    0x88
#define OP_FLO    0x89
#define OP_FLT    0x8A
#define OP_INN    0x8B
#define OP_INT    0x8C
#define OP_LOR    0x8D
#define OP_MODI   0x8E
#define OP_MPI    0x8F
#define OP_MPR    0x90
#define OP_NGI    0x91
#define OP_NGR    0x92
#define OP_NOT    0x93
#define OP_SRS    0x94
#define OP_SBI    0x95
#define OP_SBR    0x96
#define OP_SGS    0x97
#define OP_SQI    0x98
#define OP_SQR    0x99
#define OP_STO    0x9A
#define OP_IXS    0x9B
#define OP_UNI    0x9C
#define OP_NOTIMP 0x9D
#define OP_CSP    0x9E
#define OP_LDCN   0x9F
#define OP_ADJ    0xA0
#define OP_FJP    0xA1
#define OP_INCR   0xA2
#define OP_STIND  0xA3
#define OP_IXA    0xA4
#define OP_LAO    0xA5
#define OP_LSA    0xA6
#define OP_NOTIMP_A 0xA7
#define OP_MOV    0xA8
#define OP_LDO    0xA9
#define OP_SAS    0xAA
#define OP_SRO    0xAB
#define OP_XJP    0xAC
#define OP_RNP    0xAD
#define OP_CIP    0xAE
#define OP_CEQU   0xAF
#define OP_CGEQ   0xB0
#define OP_CGTR   0xB1
#define OP_LDA    0xB2
#define OP_LDC    0xB3
#define OP_CLEQ   0xB4
#define OP_CLSS   0xB5
#define OP_LOD    0xB6
#define OP_CNEQ   0xB7
#define OP_STR    0xB8
#define OP_UJP    0xB9
#define OP_LDP    0xBA
#define OP_STP    0xBB
#define OP_LDM    0xBC
#define OP_STM    0xBD
#define OP_LDB    0xBE
#define OP_STB    0xBF
#define OP_IXP    0xC0
#define OP_RBP    0xC1
#define OP_CBP    0xC2
#define OP_EQUI   0xC3
#define OP_GEQI   0xC4
#define OP_GTRI   0xC5
#define OP_LLA    0xC6
#define OP_LDCI   0xC7
#define OP_LEQI   0xC8
#define OP_LESI   0xC9
#define OP_LDL    0xCA
#define OP_NEQI   0xCB
#define OP_STL    0xCC
#define OP_CXP    0xCD
#define OP_CLP    0xCE
#define OP_CGP    0xCF
#define OP_LPA    0xD0
#define OP_NOTIMP_C 0xD1
#define OP_NOTIMP_D 0xD2
#define OP_EFJ    0xD3
#define OP_NFJ    0xD4
#define OP_BPT    0xD5
#define OP_ABORT  0xD6
#define OP_BACK   0xD7

// SIND0 (short static index and load word, index=0) is a single, distinct
// opcode -- not part of the SIND_BASE range below, which covers indices
// 1-7 (0xF9-0xFF) only.
#define OP_SIND0  0xF8

// Parameterized ranges
#define OP_SLDL_BASE 0xD8
#define OP_SLDO_BASE 0xE8
#define OP_SIND_BASE 0xF9

inline const char* PCodeOpcodeName(uint8_t opcode) {

    static const char* const names[256] = {
        // 0x00-0x7F: SLDC (short load constant; value is opcode & 0x7F)
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        "SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC","SLDC",
        // 0x80-0x9F
        "ABI","ABR","ADI","ADR","LAND","DIF","DVI","DVR",
        "CHK","FLO","FLT","INN","INT","LOR","MODI","MPI",
        "MPR","NGI","NGR","NOT","SRS","SBI","SBR","SGS",
        "SQI","SQR","STO","IXS","UNI","NOTIMP","CSP","LDCN",
        // 0xA0-0xBF
        "ADJ","FJP","INCR","STIND","IXA","LAO","LSA","NOTIMP",
        "MOV","LDO","SAS","SRO","XJP","RNP","CIP","CEQU",
        "CGEQ","CGTR","LDA","LDC","CLEQ","CLSS","LOD","CNEQ",
        "STR","UJP","LDP","STP","LDM","STM","LDB","STB",
        // 0xC0-0xDF
        "IXP","RBP","CBP","EQUI","GEQI","GTRI","LLA","LDCI",
        "LEQI","LESI","LDL","NEQI","STL","CXP","CLP","CGP",
        "LPA","NOTIMP","NOTIMP","EFJ","NFJ","BPT","ABORT","BACK",
        "SLDL","SLDL","SLDL","SLDL","SLDL","SLDL","SLDL","SLDL",
        // 0xE0-0xFF
        "SLDL","SLDL","SLDL","SLDL","SLDL","SLDL","SLDL","SLDL",
        "SLDO","SLDO","SLDO","SLDO","SLDO","SLDO","SLDO","SLDO",
        "SLDO","SLDO","SLDO","SLDO","SLDO","SLDO","SLDO","SLDO",
        "SIND0","SIND","SIND","SIND","SIND","SIND","SIND","SIND",
    };
    return names[opcode];
}

// Names CSPTBL's own procedure-number entries (0x15E7, one word-pointer
// per selector), matching that table's exact order. Used by the View >
// Op Code Count dialog to break the single CSP opcode down into
// individual routines (CSP-SQT for square root, CSP-IOC for the I/O
// completion routine, etc.) instead of lumping every standard-library
// call under one count. Indices 12-20 are unused (zero entries in the
// real table -- calls with those selectors trap into the OS via
// CSPTRAP instead of jumping to a table entry) and return nullptr;
// indices beyond the table's own end (41+) also return nullptr, and the
// caller should fall back to showing the bare selector number for those.
inline const char* CspSelectorName(uint8_t sel) {
    static const char* const names[41] = {
        "IOC","NEW","MVL","MVR","EXIT","UREAD","UWRITE","IDS","TRS","TIM","FLC","SCN", // 0-11
        nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,       // 12-20
        "GSEG","RSEG","TNC","RND","SIN","COS","LOG","ATAN","LN","EXP","SQT",           // 21-31
        "MRK","RLS","IOR","UBUSY","POT","UWAIT","UCLEAR","HLT","MEMA",                 // 32-40
    };
    if (sel >= 41) return nullptr;
    return names[sel];
}

inline bool PCodeOpcodeIsNative(uint8_t opcode) {
    switch (opcode) {
        case 0x80: // ABI
        case 0x81: // ABR (native with Z80 register compatibility off)
        case 0x83: // ADR (native with Z80 register compatibility off, FP errors fall through)
        case 0x87: // DVR (native with Z80 register compatibility off, FP errors fall through)
        case 0x89: // FLO (native with Z80 register compatibility off)
        case 0x8A: // FLT (native with Z80 register compatibility off)
        case 0x8C: // INT (native with Z80 register compatibility off)
        case 0x90: // MPR (native with Z80 register compatibility off, FP errors fall through)
        case 0x92: // NGR (native with Z80 register compatibility off)
        case 0x96: // SBR (native with Z80 register compatibility off, FP errors fall through)
        case 0x98: // SQI (native with Z80 register compatibility off)
        case 0x99: // SQR (native with Z80 register compatibility off, FP errors fall through)
        case 0x9B: // IXS (native with Z80 register compatibility off, bad index falls through)
        case 0xD3: // EFJ (native with Z80 register compatibility off, long jumps fall through)
        case 0xD4: // NFJ (native with Z80 register compatibility off, long jumps fall through)
        case 0xD5: // BPT (native with Z80 register compatibility off, halts fall through)
        case 0x82: // ADI
        case 0x84: // LAND
        case 0x85: // DIF
        case 0x86: // DVI (DIVZER divide-by-zero/overflow case falls through)
        case 0x88: // CHK
        case 0x8B: // INN (in-declared-range cases only; absolute-out-of-range and set-size-exceeded fall through)
        case 0x8D: // LOR
        case 0x8E: // MODI (DIVZER divide-by-zero/overflow case falls through)
        case 0x8F: // MPI
        case 0x91: // NGI
        case 0x93: // NOT
        case 0x94: // SRS (i<0 or j>=4080 out-of-range case falls through)
        case 0x95: // SBI
        case 0x97: // SGS (i<0 or i>=4080 out-of-range case falls through)
        case 0x9A: // STO
        case 0x9C: // UNI (Uniona sub-case only; Unionb falls through)
        case 0x9E: // CSP
        case 0x9F: // LDCN
        case 0xA0: // ADJ
        case 0xA1: // FJP
        case 0xA2: // INCR
        case 0xA3: // STIND
        case 0xA4: // IXA
        case 0xA5: // LAO
        case 0xA6: // LSA
        case 0xA8: // MOV
        case 0xA9: // LDO
        case 0xAA: // SAS
        case 0xAB: // SRO
        case 0xAC: // XJP (in-range case only; else-jump case falls through)
        case 0xAD: // RNP (same-segment case only; segment-change case falls through)
        case 0xAE: // CIP (base-level and intermediate cases; defensive fallback for the never-expected "not found" case)
        case 0xAF: // CEQU (BOOLC/WORDC/BYTEC/STRGC only; REALC/POWRC fall through)
        case 0xB0: // CGEQ (BOOLC/STRGC only; other types fall through)
        case 0xB1: // CGTR (BOOLC/STRGC only; other types fall through)
        case 0xB2: // LDA
        case 0xB3: // LDC
        case 0xB4: // CLEQ (BOOLC/STRGC only; other types fall through)
        case 0xB5: // CLSS (BOOLC/STRGC only; other types fall through)
        case 0xB6: // LOD
        case 0xB7: // CNEQ (BOOLC/WORDC/BYTEC/STRGC only; REALC/POWRC fall through)
        case 0xB8: // STR
        case 0xB9: // UJP
        case 0xBA: // LDP
        case 0xBB: // STP
        case 0xBC: // LDM (count==0 edge case falls through)
        case 0xBD: // STM
        case 0xBE: // LDB
        case 0xBF: // STB
        case 0xC0: // IXP
        case 0xC1: // RBP (same-segment case only, matching RNP)
        case 0xC2: // CBP (same-segment; assembly-proc path falls through)
        case 0xCD: // CXP (same-segment fast path only; different-segment cases fall through)
        case 0xCE: // CLP (assembly-proc path falls through)
        case 0xCF: // CGP (assembly-proc path falls through)
        case 0xD0: // LPA
        case 0xD7: // BACK -- a genuine, distinct p-code opcode (not the
                    // fetch-loop label at 0x03B0, despite sharing its
                    // name): its XFRTBL entry points directly at BACK's own
                    // fetch-loop entry, so it's a true no-op -- dispatching
                    // to it just re-enters the fetch loop immediately, with
                    // no body of its own to port. Already at the minimum
                    // possible cost with zero code changes, so there's no
                    // corresponding case in the switch below.
        case 0xC3: // EQUI
        case 0xC4: // GEQI
        case 0xC5: // GTRI
        case 0xC6: // LLA
        case 0xC7: // LDCI
        case 0xC8: // LEQI
        case 0xC9: // LESI
        case 0xCA: // LDL
        case 0xCB: // NEQI
        case 0xCC: // STL
        case OP_SIND0: // SIND0
            return true;
        default:
            // SLDC: all of 0x00-0x7F.
            if (opcode <= 0x7F) return true;
            // SLDL: all of 0xD8-0xE7. SLDO: all of 0xE8-0xF7.
            if (opcode >= 0xD8 && opcode <= 0xF7) return true;
            // SIND: all of 0xF9-0xFF.
            if (opcode >= 0xF9 && opcode <= 0xFF) return true;
            return false;
    }
}

// Run-time error labels of the Z80 interpreter (RUN-TIME ERROR SUPPORT,
// 0x03BE-0x0430): the error number each one passes to XEQERR, or -1.
// Used by NativeErrors.inc, which performs XEQERR natively.
inline int NativeErrorCode(uint16_t pc) {
    switch (pc) {
        case 0x03DA: return 1;  // INVNDX  value range
        case 0x03DF: return 2;  // NOPROC  no proc in seg-table
        case 0x03E4: return 3;  // NOEXIT  exit from uncalled proc
        case 0x03E9: return 4;  // STKOVR  stack overflow
        case 0x03F4: return 5;  // INTOVR  integer overflow
        case 0x03F9: return 6;  // DIVZER  divide by zero
        case 0x03FE: return 7;  // BADMEM
        case 0x0403: return 8;  // UBREAK  user break
        case 0x0408: return 9;  // SYIOER  system I/O error
        case 0x040D: return 10; // UIOERR  user I/O error
        case 0x0412: return 11; // NOTIMP  instruction not implemented
        case 0x041B: return 12; // FPIERR  floating point error
        case 0x0420: return 13; // S2LONG  string overflow
        case 0x0425: return 14; // HLT     halt
        case 0x042E: return 15; // BPTHLT  breakpoint / conditional halt
        default:     return -1;
    }
}
